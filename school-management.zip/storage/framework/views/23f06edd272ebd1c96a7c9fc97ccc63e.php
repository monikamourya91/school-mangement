

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row d-flex mb-2 ">
            <div class="col-md-6">
               <h1>Student List</h1>
            </div>
            <div class="col-md-6 text-md-end d-flex mb-2 justify-content-end">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary mt-3">Back</a>
            </div>
        </div>

        <!-- Search Form -->
        <form action="<?php echo e(route('students.index')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?php echo e($search); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </form>

        <!-- Students List by Class -->
        <?php $__empty_1 = true; $__currentLoopData = $studentsByClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <h3><?php echo e($class); ?></h3>
            <ul class="list-group mb-4">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"><?php echo e($student->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-info">No students found.</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/students/classwise.blade.php ENDPATH**/ ?>