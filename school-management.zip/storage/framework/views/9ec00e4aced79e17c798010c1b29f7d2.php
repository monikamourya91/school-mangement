<!-- resources/views/dashboard.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1 class="mb-4 text-center">School Management</h1>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Students</h5>
                        <p class="card-text"><?php echo e($studentCount); ?> Students</p>
                        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-primary">View Students</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">All Student Class wise</h5>
                        <p class="card-text"><?php echo e($studentCount); ?> Students</p>
                        <a href="<?php echo e(route('students.wise')); ?>" class="btn btn-primary">View Students</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Teachers</h5>
                        <p class="card-text"><?php echo e($teacherCount); ?> Teachers</p>
                        <a href="<?php echo e(route('teachers.index')); ?>" class="btn btn-primary">View Teachers</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Subjects</h5>
                        <p class="card-text"><?php echo e($subjectCount); ?> Subjects</p>
                        <a href="<?php echo e(route('subjects.index')); ?>" class="btn btn-primary">View Subjects</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/dashboard.blade.php ENDPATH**/ ?>