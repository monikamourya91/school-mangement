
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Subjects of <?php echo e($student->name); ?></h1>

        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="card-body">
                    <p class="card-title"><?php echo e($subject->name); ?></p>
                </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/students/subjects.blade.php ENDPATH**/ ?>