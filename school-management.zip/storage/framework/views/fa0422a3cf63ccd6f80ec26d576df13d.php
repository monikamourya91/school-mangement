

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row d-flex mb-2">
            <div class="col-md-6">
                <h1>Teachers List</h1>
            </div>
            <div class="col-md-6 text-md-end d-flex mb-2 justify-content-end">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary mt-3">Back</a>
            </div>
        </div>
       

        <div class="mb-3">
            <a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-primary">Add Teacher</a>
        </div>

        <?php if($teachers->isEmpty()): ?>
            <div class="alert alert-info">No teachers found.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Age</th>
                        <th>Sex</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($teacher->name); ?></td>
                            <td>
                                <?php if($teacher->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $teacher->image)); ?>" alt="<?php echo e($teacher->name); ?>" width="50">
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($teacher->age); ?></td>
                            <td><?php echo e($teacher->sex); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/teachers/index.blade.php ENDPATH**/ ?>