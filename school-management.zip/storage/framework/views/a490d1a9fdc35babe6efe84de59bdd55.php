

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Student List</h1>

        <div class="mb-3">
            <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">Create New</a>
        </div>

        <!-- Search Form -->
        <form action="<?php echo e(route('students.index')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?php echo e(request()->input('search')); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </form>
        <!-- Student List -->
        <?php if($students->isEmpty()): ?>
            <div class="alert alert-info">No students found.</div>
        <?php else: ?>
            <table class="table">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Class</th>
                    <th>Roll Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $count = 1; 
                ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($count++); ?></td>
                    <td>
                        <?php if($student->image): ?>
                            <img src="<?php echo e(asset('storage/' . $student->image)); ?>" alt="<?php echo e($student->name); ?>" style="max-width: 100px; max-height: 100px;">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($student->name); ?></td>
                    <td><?php echo e($student->age); ?></td>
                    <td><?php echo e($student->class); ?></td>
                    <td><?php echo e($student->roll_number); ?></td>
                    <td>
                        <a href="<?php echo e(route('students.subjects', $student->id)); ?>" class="btn btn-primary">View Subjects & Teachers</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
            <!-- Pagination Links -->
            <?php echo e($students->links()); ?>

        <?php endif; ?>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/students/index.blade.php ENDPATH**/ ?>