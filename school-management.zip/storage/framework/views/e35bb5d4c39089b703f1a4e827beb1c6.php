

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 d-flex mb-2">
               <h1>Subject List</h1>
            </div>
            <div class="col-md-6 text-md-end d-flex mb-2 justify-content-end">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary mt-3">Back</a>
            </div>
        </div>
        <div class="mb-3">
            <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary">Add Subject</a>
        </div>

        <?php if($subjects->isEmpty()): ?>
            <div class="alert alert-info">No subjects found.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Class</th>
                        <th>languages</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subject->name); ?></td>
                            <td><?php echo e($subject->class); ?></td>
                            <td>
                                <?php $__currentLoopData = json_decode($subject->language); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($lang); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management\resources\views/subjects/index.blade.php ENDPATH**/ ?>